<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once './config.php';

$database = new Database();
$db = $database->getConnection();

$action = isset($_GET['action']) ? $_GET['action'] : '';

// Function to check admin simple token or param
function checkAdmin($userId, $db) {
    if(!$userId) return false;
    $stmt = $db->prepare("SELECT is_admin FROM users WHERE id = :id");
    $stmt->bindParam(":id", $userId);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    return ($user && $user['is_admin'] == 1);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $admin_id = isset($_GET['admin_id']) ? $_GET['admin_id'] : 0;
    
    if(!checkAdmin($admin_id, $db)) {
        echo json_encode(["status" => "error", "message" => "Permission denied."]);
        exit;
    }
    
    // GET: Dashboard Stats
    if ($action == 'dashboard_stats') {
        $stats = [];
        // Users
        $stmt = $db->query("SELECT COUNT(*) as count FROM users WHERE is_admin=0");
        $stats['users'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        // Pending Places
        $stmt = $db->query("SELECT COUNT(*) as count FROM places WHERE status='pending'");
        $stats['pending_places'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        // Total Reviews
        $stmt = $db->query("SELECT COUNT(*) as count FROM reviews");
        $stats['reviews'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        echo json_encode($stats);
    }
    
    // GET: Pending Places List
    else if ($action == 'pending_places') {
        $stmt = $db->query("SELECT p.*, c.name as category, u.fullname as author 
                            FROM places p 
                            LEFT JOIN categories c ON p.category_id = c.id
                            LEFT JOIN users u ON p.submitted_by = u.id
                            WHERE p.status = 'pending' ORDER BY p.created_at ASC");
        $places = [];
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            array_push($places, $row);
        }
        echo json_encode($places);
    }
    
    // GET: ALL Users
    else if ($action == 'users_list') {
        $stmt = $db->query("SELECT id, username, fullname, points, created_at, avatar FROM users WHERE is_admin=0 ORDER BY id DESC LIMIT 50");
        $users = [];
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            array_push($users, $row);
        }
        echo json_encode($users);
    }
} 
else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    $postAction = isset($data->action) ? $data->action : '';
    $admin_id = isset($data->admin_id) ? $data->admin_id : 0;
    
    if(!checkAdmin($admin_id, $db)) {
        echo json_encode(["status" => "error", "message" => "Permission denied."]);
        exit;
    }

    // POST: Update Place Status (Approve / Reject)
    if ($postAction == 'update_place_status') {
        if(!empty($data->place_id) && !empty($data->status)) {
            $stmt = $db->prepare("UPDATE places SET status=:status WHERE id=:id");
            $stmt->bindParam(":status", $data->status);
            $stmt->bindParam(":id", $data->place_id);
            if($stmt->execute()) {
                echo json_encode(["status" => "success", "message" => "Đã duyệt/từ chối địa điểm."]);
            } else {
                echo json_encode(["status" => "error", "message" => "Lỗi CSDL."]);
            }
        }
    }
    
    // POST: Delete User
    else if ($postAction == 'delete_user') {
        if(!empty($data->user_id)) {
            $stmt = $db->prepare("DELETE FROM users WHERE id=:id AND is_admin=0");
            $stmt->bindParam(":id", $data->user_id);
            if($stmt->execute()) {
                echo json_encode(["status" => "success", "message" => "Đã xoá người dùng."]);
            } else {
                echo json_encode(["status" => "error", "message" => "Lỗi CSDL."]);
            }
        }
    }
    
    // POST: Delete Review
    else if ($postAction == 'delete_review') {
         if(!empty($data->review_id)) {
            $stmt = $db->prepare("DELETE FROM reviews WHERE id=:id");
            $stmt->bindParam(":id", $data->review_id);
            if($stmt->execute()) {
                echo json_encode(["status" => "success", "message" => "Đã xoá đánh giá."]);
            } else {
                echo json_encode(["status" => "error", "message" => "Lỗi CSDL."]);
            }
        }
    }
}
?>
