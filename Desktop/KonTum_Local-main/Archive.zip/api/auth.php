<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once './config.php';

$database = new Database();
$db = $database->getConnection();

$data = json_decode(file_get_contents("php://input"));

if(!isset($data->action)){
    echo json_encode(["status" => "error", "message" => "Thiếu param action."]);
    exit();
}

$action = $data->action;

if ($action == 'login') {
    if(!empty($data->username) && !empty($data->password)){
        $query = "SELECT id, username, password, fullname, avatar, points, dark_mode, is_admin FROM users WHERE username = :username";
        $stmt = $db->prepare($query);
        $stmt->bindParam(":username", $data->username);
        $stmt->execute();
        
        if($stmt->rowCount() > 0){
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if(password_verify($data->password, $row['password'])){
                
                // Remove password from response
                unset($row['password']);
                
                echo json_encode([
                    "status" => "success",
                    "message" => "Đăng nhập thành công.",
                    "user" => $row
                ]);
            } else {
                echo json_encode(["status" => "error", "message" => "Mật khẩu không đúng."]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Tài khoản không tồn tại."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Vui lòng nhập Username và Password."]);
    }
}
elseif ($action == 'register') {
    if(!empty($data->username) && !empty($data->password) && !empty($data->fullname)){
        
        // Check if username exists
        $check_query = "SELECT id FROM users WHERE username = :username";
        $check_stmt = $db->prepare($check_query);
        $check_stmt->bindParam(":username", $data->username);
        $check_stmt->execute();
        
        if($check_stmt->rowCount() > 0){
            echo json_encode(["status" => "error", "message" => "Tên đăng nhập đã tồn tại."]);
            exit();
        }
    
        $query = "INSERT INTO users SET username=:username, password=:password, fullname=:fullname";
        $stmt = $db->prepare($query);
        
        // Sanitize & hash 
        $username = htmlspecialchars(strip_tags($data->username));
        $fullname = htmlspecialchars(strip_tags($data->fullname));
        $password = password_hash($data->password, PASSWORD_BCRYPT);
        
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":password", $password);
        $stmt->bindParam(":fullname", $fullname);
        
        if($stmt->execute()){
            echo json_encode(["status" => "success", "message" => "Đăng ký thành công."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Không thể đăng ký tài khoản."]);
        }
    } else {
         echo json_encode(["status" => "error", "message" => "Vui lòng điền đủ thông tin."]);
    }
} else {
     echo json_encode(["status" => "error", "message" => "Action không hợp lệ."]);
}
?>
