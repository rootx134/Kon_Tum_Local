<?php
/**
 * Database Configuration - PRODUCTION (Shared Hosting)
 * ----------------------------------------------------
 * Khi deploy lên hosting, đổi tên file này thành config.php
 * và điền thông tin đăng nhập database từ cPanel.
 */

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ======================================================
// THAY ĐỔI CÁC THÔNG TIN NÀY THEO CẤU HÌNH HOSTING
// ======================================================
define('DB_HOST', 'localhost');             // Thường là 'localhost'
define('DB_USER', 'tenuser_dbuser');        // Thay bằng Database User trong cPanel
define('DB_PASS', 'mat_khau_manh_o_day');  // Thay bằng Database Password
define('DB_NAME', 'tenuser_kontumdb');     // Thay bằng tên Database trong cPanel
// ======================================================

class Database {
    private $host = DB_HOST;
    private $db_name = DB_NAME;
    private $username = DB_USER;
    private $password = DB_PASS;
    private $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->exec("set names utf8mb4");
        } catch(PDOException $exception) {
            echo json_encode(["status" => "error", "message" => "Connection error: " . $exception->getMessage()]);
            exit;
        }
        return $this->conn;
    }
}
?>
