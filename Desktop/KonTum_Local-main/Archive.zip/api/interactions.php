<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once './config.php';

$database = new Database();
$db = $database->getConnection();

$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    $postAction = isset($data->action) ? $data->action : '';

    // POST: Submit a Review
    if ($postAction == 'add_review') {
        if(!empty($data->place_id) && !empty($data->user_id) && !empty($data->rating) && !empty($data->content)){
            
            // Start transaction
            $db->beginTransaction();
            
            try {
                // Insert Review
                $query = "INSERT INTO reviews SET place_id=:place_id, user_id=:user_id, rating=:rating, content=:content";
                $stmt = $db->prepare($query);
                
                $stmt->bindParam(":place_id", $data->place_id);
                $stmt->bindParam(":user_id", $data->user_id);
                $stmt->bindParam(":rating", $data->rating);
                $stmt->bindParam(":content", htmlspecialchars(strip_tags($data->content)));
                
                $stmt->execute();
                $reviewId = $db->lastInsertId();
                
                // Insert Images if available
                if(!empty($data->images) && is_array($data->images)) {
                    $imgQuery = "INSERT INTO review_images (review_id, image_url) VALUES (:rid, :url)";
                    $imgStmt = $db->prepare($imgQuery);
                    
                    foreach($data->images as $url) {
                        $imgStmt->bindParam(":rid", $reviewId);
                        $imgStmt->bindParam(":url", $url);
                        $imgStmt->execute();
                    }
                }
                
                // [NEW] Cộng 10 điểm cho người đánh giá
                $updatePoints = $db->prepare("UPDATE users SET points = points + 10 WHERE id = :uid");
                $updatePoints->bindParam(":uid", $data->user_id);
                $updatePoints->execute();

                $db->commit();
                echo json_encode(["status" => "success", "message" => "Đã gửi đánh giá thành công! (+10đ)"]);
                
            } catch (Exception $e) {
                $db->rollBack();
                echo json_encode(["status" => "error", "message" => "Lỗi hệ thống: " . $e->getMessage()]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Vui lòng nhập đầy đủ thông tin"]);
        }
    }
    
    // POST: Toggle Like on Review -> Point Update Automation
    else if ($postAction == 'toggle_like') {
        if(!empty($data->user_id) && !empty($data->review_id)) {
            
            $db->beginTransaction();
            try {
                // 1. Check if liked
                $check = $db->prepare("SELECT 1 FROM likes WHERE user_id=:uid AND entity_type='review' AND entity_id=:rid");
                $check->bindParam(":uid", $data->user_id);
                $check->bindParam(":rid", $data->review_id);
                $check->execute();
                
                // 2. Get the author of the review to modify points
                $reviewCheck = $db->prepare("SELECT user_id FROM reviews WHERE id=:rid");
                $reviewCheck->bindParam(":rid", $data->review_id);
                $reviewCheck->execute();
                $authorRow = $reviewCheck->fetch(PDO::FETCH_ASSOC);
                $authorId = $authorRow ? $authorRow['user_id'] : 0;
                
                if($check->rowCount() > 0) {
                    // Already liked -> Dislike (Remove record + Decrement point)
                    $del = $db->prepare("DELETE FROM likes WHERE user_id=:uid AND entity_type='review' AND entity_id=:rid");
                    $del->bindParam(":uid", $data->user_id);
                    $del->bindParam(":rid", $data->review_id);
                    $del->execute();
                    
                    if($authorId > 0 && $authorId != $data->user_id) { // Don't sub point if liker is author himself
                         $db->query("UPDATE users SET points = points - 1 WHERE id = $authorId AND points > 0");
                    }
                    
                    $db->commit();
                    echo json_encode(["status" => "success", "liked" => false, "message" => "Đã bỏ Yêu thích"]);
                } else {
                    // Not liked -> Like (Add record + Increment point)
                    $ins = $db->prepare("INSERT INTO likes SET user_id=:uid, entity_type='review', entity_id=:rid");
                    $ins->bindParam(":uid", $data->user_id);
                    $ins->bindParam(":rid", $data->review_id);
                    $ins->execute();
                    
                    if($authorId > 0 && $authorId != $data->user_id) { // Don't add point if liker is author himself
                         $db->query("UPDATE users SET points = points + 1 WHERE id = $authorId");
                    }
                    
                    $db->commit();
                    echo json_encode(["status" => "success", "liked" => true, "message" => "Đã Yêu thích"]);
                }
            } catch (Exception $e) {
                $db->rollBack();
                echo json_encode(["status" => "error", "message" => "Lỗi CSDL."]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Thiếu param."]);
        }
    }
}
?>
