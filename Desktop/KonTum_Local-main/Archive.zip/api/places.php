<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once './config.php';

$database = new Database();
$db = $database->getConnection();

$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handling JSON POST data
    $data = json_decode(file_get_contents("php://input"));
    $postAction = isset($data->action) ? $data->action : '';

    // POST: Thêm địa điểm mới
    if ($postAction == 'add_place') {
        if(!empty($data->name) && !empty($data->category_id) && !empty($data->address)){
            // Insert Place Data
            $query = "INSERT INTO places SET category_id=:category_id, name=:name, description=:description, address=:address, latitude=:lat, longitude=:lng, submitted_by=:user_id";
            $stmt = $db->prepare($query);
            
            $stmt->bindParam(":category_id", $data->category_id);
            $stmt->bindParam(":name", htmlspecialchars(strip_tags($data->name)));
            $stmt->bindParam(":description", htmlspecialchars(strip_tags($data->description)));
            $stmt->bindParam(":address", htmlspecialchars(strip_tags($data->address)));
            $stmt->bindParam(":lat", $data->latitude);
            $stmt->bindParam(":lng", $data->longitude);
            $stmt->bindParam(":user_id", $data->user_id);
            
            if($stmt->execute()){
                $placeId = $db->lastInsertId();
                
                // [NEW] Cộng 15 điểm cho người đóng góp
                if(!empty($data->user_id)) {
                    $updatePoints = $db->prepare("UPDATE users SET points = points + 15 WHERE id = :uid");
                    $updatePoints->bindParam(":uid", $data->user_id);
                    $updatePoints->execute();
                }

                echo json_encode(["status" => "success", "message" => "Đóng góp địa điểm thành công! Chờ duyệt (+15đ).", "place_id" => $placeId]);
            } else {
                echo json_encode(["status" => "error", "message" => "Lỗi server khi thêm địa điểm."]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Thiếu thông tin bắt buộc."]);
        }
    }
} else if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    
    // GET: Danh sách danh mục (Categories)
    if ($action == 'get_categories') {
        $query = "SELECT * FROM categories ORDER BY id ASC";
        $stmt = $db->prepare($query);
        $stmt->execute();
        
        $categories = array();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            array_push($categories, $row);
        }
        echo json_encode($categories);
    }
    
    // GET: Lấy danh sách Địa điểm (Approved)
    else if ($action == 'get_places') {
        $cat_id = isset($_GET['category_id']) ? $_GET['category_id'] : null;
        
        $query = "SELECT p.*, c.name as category_name, c.icon, u.fullname as author_name 
                  FROM places p 
                  LEFT JOIN categories c ON p.category_id = c.id 
                  LEFT JOIN users u ON p.submitted_by = u.id 
                  WHERE p.status = 'approved'";
                  
        if($cat_id) {
            $query .= " AND p.category_id = :cat_id";
        }
        
        $query .= " ORDER BY p.created_at DESC";
        $stmt = $db->prepare($query);
        
        if($cat_id) {
            $stmt->bindParam(":cat_id", $cat_id);
        }
        
        $stmt->execute();
        
        $places = array();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            // Fetch first image as thumbnail
            $imgQuery = "SELECT image_url FROM place_images WHERE place_id = :place_id LIMIT 1";
            $imgStmt = $db->prepare($imgQuery);
            $imgStmt->bindParam(":place_id", $row['id']);
            $imgStmt->execute();
            $imgRow = $imgStmt->fetch(PDO::FETCH_ASSOC);
            $row['thumbnail'] = $imgRow ? $imgRow['image_url'] : 'default_place.jpg';
                
            array_push($places, $row);
        }
        echo json_encode($places);
    }
    
    // GET: Lấy Bài viết Khám phá Feed
    else if ($action == 'get_feed') {
        $user_id = isset($_GET['user_id']) ? $_GET['user_id'] : 0;
        
        // Feed algorithm: Priorities following users, then created dates, then likes
        // For simplicity, we just fetch latest reviews with related user and place info
        $query = "SELECT r.*, u.fullname, u.avatar, p.name as place_name, 
                  (SELECT COUNT(*) FROM likes WHERE entity_type='review' AND entity_id=r.id) as total_likes,
                  (SELECT COUNT(*) FROM comments WHERE review_id=r.id) as total_comments
                  FROM reviews r
                  JOIN users u ON r.user_id = u.id
                  JOIN places p ON r.place_id = p.id
                  ORDER BY r.created_at DESC LIMIT 20";
                  
        $stmt = $db->prepare($query);
        $stmt->execute();
        
        $feed = array();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            // Fetch associated images for review
            $imgQuery = "SELECT image_url FROM review_images WHERE review_id = :review_id";
            $imgStmt = $db->prepare($imgQuery);
            $imgStmt->bindParam(":review_id", $row['id']);
            $imgStmt->execute();
            
            $images = [];
            while ($imgRow = $imgStmt->fetch(PDO::FETCH_ASSOC)) {
                array_push($images, $imgRow['image_url']);
            }
            $row['images'] = $images;
            
            // Check if current user liked this
            if($user_id > 0) {
                $likeCheck = $db->prepare("SELECT 1 FROM likes WHERE user_id=:uid AND entity_type='review' AND entity_id=:rid");
                $likeCheck->bindParam(":uid", $user_id);
                $likeCheck->bindParam(":rid", $row['id']);
                $likeCheck->execute();
                $row['liked_by_me'] = $likeCheck->rowCount() > 0;
            } else {
                $row['liked_by_me'] = false;
            }
            
            array_push($feed, $row);
        }
        echo json_encode($feed);
    }
}
?>
