<?php
/**
 * RESTful File Upload API
 */
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Method not allowed"]);
    exit;
}

$target_dir = "../assets/img/uploads/";
if (!is_dir($target_dir)) {
    mkdir($target_dir, 0755, true);
}

$response = ["status" => "success", "urls" => [], "errors" => []];

if(isset($_FILES['images'])) {
    $total = count($_FILES['images']['name']);
    
    for( $i=0 ; $i < $total ; $i++ ) {
        if ($_FILES['images']['error'][$i] === UPLOAD_ERR_OK) {
            $tmpFilePath = $_FILES['images']['tmp_name'][$i];
            
            if ($tmpFilePath != ""){
                // Extract extension
                $fileInfo = pathinfo($_FILES['images']['name'][$i]);
                $extension = strtolower($fileInfo['extension']);
                
                // Allow only images
                $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                if(in_array($extension, $allowed)) {
                    // Generate safe random name
                    $newFilename = uniqid('img_') . time() . '.' . $extension;
                    $newFilePath = $target_dir . $newFilename;
                    
                    if(move_uploaded_file($tmpFilePath, $newFilePath)) {
                        // Return absolute or relative public path
                        $publicUrl = "assets/img/uploads/" . $newFilename;
                        array_push($response['urls'], $publicUrl);
                    } else {
                        array_push($response['errors'], "Lỗi khi lưu file: " . $_FILES['images']['name'][$i]);
                    }
                } else {
                    array_push($response['errors'], "Định dạng không hợp lệ ($extension): " . $_FILES['images']['name'][$i]);
                }
            }
        }
    }
} else {
    $response = ["status" => "error", "message" => "Không tìm thấy file upload."];
}

// Return result length to determine success
if(count($response['urls']) > 0) {
    if(count($response['errors']) > 0) {
        $response['status'] = "partial";
        $response['message'] = "Đã upload vài ảnh, nhưng một số bị lỗi.";
    } else {
        $response['message'] = "Đã upload toàn bộ ảnh thành công.";
    }
} else if(count($response['errors']) > 0) {
    $response['status'] = "error";
    $response['message'] = implode(", ", $response['errors']);
}

echo json_encode($response);
?>
