document.addEventListener('DOMContentLoaded', () => {

    // --- State & Config ---
    const API_URL = 'https://local.kontumplus.com/api';
    let currentUser = JSON.parse(localStorage.getItem('user_vtkt')) || null; // Reset về null để sếp test luồng Auth mới

    // --- DOM Elements ---
    const htmlEl = document.documentElement;
    const navBtns = document.querySelectorAll('.nav-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    const darkModeSwitch = document.getElementById('darkModeSwitch');

    // Toast DOM
    const toast = document.getElementById('toast');
    const toastMsg = document.getElementById('toastMsg');
    let toastTimeout;


    // --- 1. Init App ---
    initApp();

    function initApp() {
        // Init theme
        const savedTheme = localStorage.getItem('theme_vtkt');
        if (savedTheme === 'dark') {
            setDarkMode(true);
            if (darkModeSwitch) darkModeSwitch.checked = true;
        } else {
            setDarkMode(false);
            if (darkModeSwitch) darkModeSwitch.checked = false;
        }

        // Render or hide Profile based on login status
        const profileContent = document.getElementById('profileContent');
        const authOverlay = document.getElementById('authOverlay');

        if (currentUser) {
            // Logged in: show profile, hide auth overlay
            if (authOverlay) authOverlay.classList.add('hidden');
            if (profileContent) profileContent.classList.remove('hidden');
            document.getElementById('userNameProfile').textContent = currentUser.fullname;
            document.getElementById('userAccountName').textContent = currentUser.username;
            document.getElementById('profilePoints').textContent = currentUser.points;
        } else {
            // Not logged in: hide profile content
            if (profileContent) profileContent.classList.add('hidden');
        }
    }


    // --- 2. UI Interactions (Theme, Tabs, Toast) ---

    // Toggle Dark Mode via Switch
    if (darkModeSwitch) {
        darkModeSwitch.addEventListener('change', (e) => {
            setDarkMode(e.target.checked);
        });
    }

    function setDarkMode(isDark) {
        if (isDark) {
            htmlEl.classList.add('dark');
            htmlEl.setAttribute('data-theme', 'dark');
            localStorage.setItem('theme_vtkt', 'dark');
        } else {
            htmlEl.classList.remove('dark');
            htmlEl.setAttribute('data-theme', 'light');
            localStorage.setItem('theme_vtkt', 'light');
        }
    }

    // Bottom Navigation Logic
    navBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const targetId = btn.getAttribute('data-target');

            // Re-style buttons
            navBtns.forEach(b => {
                b.classList.remove('active', 'text-primary');
                b.classList.add('text-gray-400');
                const icon = b.querySelector('i');
                if (icon.classList.contains('fa-solid')) {
                    // icon.classList.replace('fa-solid', 'fa-regular'); // Optional: change style
                }
            });
            btn.classList.add('active', 'text-primary');
            btn.classList.remove('text-gray-400');

            // Show target tab
            tabContents.forEach(tab => {
                tab.classList.remove('active');
                if (tab.id === `tab-${targetId}`) {
                    tab.classList.add('active');

                    // Specific logic on tab switch
                    if (targetId === 'profile' && !currentUser) {
                        const authOverlay = document.getElementById('authOverlay');
                        if (authOverlay) authOverlay.classList.remove('hidden');
                    }
                }
            });
        });
    });

    // Toast Notification Maker
    window.showToast = function (message, type = 'success') {
        toastMsg.textContent = message;
        toast.style.opacity = '1';
        toast.style.pointerEvents = 'auto';
        toast.style.transform = 'translateX(-50%) translateY(10px)';

        clearTimeout(toastTimeout);
        toastTimeout = setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.pointerEvents = 'none';
            toast.style.transform = 'translateX(-50%) translateY(0)';
        }, 3000);
    };

    // Logout Profile
    const logoutBtnProfile = document.getElementById('logoutBtnProfile');
    if (logoutBtnProfile) {
        logoutBtnProfile.addEventListener('click', () => {
            localStorage.removeItem('user_vtkt');
            showToast("Đã đăng xuất");
            setTimeout(() => window.location.reload(), 1000);
        });
    }

});

// --- 10. Auth System UI Handling ---
const authOverlay = document.getElementById('authOverlay');
const closeAuthBtn = document.getElementById('closeAuthBtn');
const switchAuthBtn = document.getElementById('switchAuthBtn');
const authLoginForm = document.getElementById('authLoginForm');
const authRegisterForm = document.getElementById('authRegisterForm');
const authTitle = document.getElementById('authTitle');
const authSubtitle = document.getElementById('authSubtitle');
const goToLoginBtn = document.getElementById('goToLoginBtn');

if (goToLoginBtn) {
    goToLoginBtn.addEventListener('click', () => {
        authOverlay.classList.remove('hidden');
    });
}

if (closeAuthBtn) {
    closeAuthBtn.addEventListener('click', () => {
        authOverlay.classList.add('hidden');
    });
}

if (switchAuthBtn) {
    switchAuthBtn.addEventListener('click', () => {
        const isLoginVisible = !authLoginForm.classList.contains('hidden');
        if (isLoginVisible) {
            // Switch to Register
            authLoginForm.classList.add('hidden');
            authRegisterForm.classList.remove('hidden');
            authTitle.textContent = "Tạo tài khoản mới";
            authSubtitle.textContent = "Hoàn thành các thông tin bên dưới để bắt đầu.";
            switchAuthBtn.innerHTML = 'Đã có tài khoản? <span class="text-[#ff5500]">Đăng nhập</span>';
        } else {
            // Switch to Login
            authLoginForm.classList.remove('hidden');
            authRegisterForm.classList.add('hidden');
            authTitle.textContent = "Chào mừng trở lại!";
            authSubtitle.textContent = "Đăng nhập để tiếp tục khám phá Kon Tum cùng chúng tôi.";
            switchAuthBtn.innerHTML = 'Chưa có tài khoản? <span class="text-[#ff5500]">Đăng ký ngay</span>';
        }
    });
}

// Login Submission
if (authLoginForm) {
    authLoginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('loginUsername').value.trim();
        const password = document.getElementById('loginPassword').value.trim();

        if (!username || !password) {
            showToast("Vui lòng nhập đủ thông tin!", "error");
            return;
        }

        try {
            const res = await fetch(`${API_URL}/auth.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'login', username, password })
            });
            const data = await res.json();

            if (data.status === 'success') {
                showToast("Đăng nhập thành công!", "success");
                localStorage.setItem('user_vtkt', JSON.stringify(data.user));
                setTimeout(() => window.location.reload(), 1000);
            } else {
                showToast(data.message, "error");
            }
        } catch (err) {
            console.error(err);
            showToast("Lỗi kết nối máy chủ.", "error");
        }
    });
}

// Register Submission
if (authRegisterForm) {
    authRegisterForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const fullname = document.getElementById('regFullname').value.trim();
        const username = document.getElementById('regUsername').value.trim();
        const password = document.getElementById('regPassword').value.trim();

        if (!fullname || !username || !password) {
            showToast("Vui lòng nhập đủ thông tin!", "error");
            return;
        }

        try {
            const res = await fetch(`${API_URL}/auth.php`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'register', fullname, username, password })
            });
            const data = await res.json();

            if (data.status === 'success') {
                showToast("Đăng ký thành công!", "success");
                // Switch to login
                switchAuthBtn.click();
                document.getElementById('loginUsername').value = username;
                document.getElementById('loginPassword').focus();
            } else {
                showToast(data.message, "error");
            }
        } catch (err) {
            console.error(err);
            showToast("Lỗi kết nối máy chủ.", "error");
        }
    });
}

