document.addEventListener('DOMContentLoaded', () => {
    const API_URL = 'https://local.kontumplus.com/api';
    const feedContainer = document.getElementById('feedContainer');
    
    // --- Render Explore Feed ---
    async function loadFeed() {
        if (!feedContainer) return;
        try {
            const res = await fetch(`${API_URL}/places.php?action=get_places`);
            const data = await res.json();
            
            if(data.status === 'success') {
                renderFeed(data.data);
            }
        } catch (err) {
            console.error("Gặp lỗi tải feed:", err);
        }
    }

    function renderFeed(places) {
        feedContainer.innerHTML = '';
        
        places.forEach(place => {
            const card = document.createElement('div');
            card.className = 'bg-white dark:bg-darkCard rounded-3xl overflow-hidden shadow-sm border border-gray-50 dark:border-[#2c2c2e] mb-4 active:scale-[0.98] transition cursor-pointer place-card-click';
            card.dataset.id = place.id;
            
            // Thumbnail
            const imgUrl = place.image_url ? `${API_URL}/../${place.image_url}` : 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&q=80&w=800';
            
            // Generate some random stats if not provided back by API yet
            const rating = (Math.random() * (5 - 3.5) + 3.5).toFixed(1);
            const reviewCount = Math.floor(Math.random() * 100);

            card.innerHTML = `
                <div class="relative w-full aspect-video bg-gray-200 dark:bg-gray-800">
                    <img src="${imgUrl}" class="w-full h-full object-cover">
                    <div class="absolute top-4 left-4 bg-black/50 backdrop-blur-md text-white text-xs font-bold px-2 py-1 rounded-lg">
                        <i class="fa-solid fa-star text-yellow-400 text-[10px]"></i> ${rating}
                    </div>
                </div>
                <div class="p-4">
                    <div class="flex items-start justify-between gap-2">
                        <div class="flex-1">
                            <h3 class="font-extrabold text-lg leading-tight mb-1 text-gray-900 dark:text-white line-clamp-1">${place.name}</h3>
                            <p class="text-sm text-gray-500 font-medium flex items-center gap-1"><i class="fa-solid fa-location-dot"></i> <span class="line-clamp-1">${place.address}</span></p>
                        </div>
                        <div class="w-10 h-10 rounded-full bg-gray-50 dark:bg-[#121212] flex items-center justify-center flex-shrink-0 text-gray-400">
                            <i class="fa-regular fa-heart"></i>
                        </div>
                    </div>
                </div>
            `;
            
            // Add click listener
            card.addEventListener('click', () => openPlaceDetail(place, imgUrl, rating, reviewCount));
            feedContainer.appendChild(card);
        });
    }

    // --- Detail Modal ---
    const placeDetailModal = document.getElementById('placeDetailModal');
    const closePlaceDetail = document.getElementById('closePlaceDetail');

    function openPlaceDetail(place, imgUrl, rating, reviewCount) {
        if(!placeDetailModal) return;
        
        // Cập nhật thông tin UI
        document.getElementById('detailPlaceImage').src = imgUrl;
        document.getElementById('detailPlaceName').textContent = place.name;
        document.getElementById('detailPlaceAddress').querySelector('span').textContent = place.address;
        
        // Category label fake mapper
        const categories = {1: 'Ăn uống', 2: 'Giải trí', 3: 'Khách sạn', 4: 'Du lịch'};
        document.getElementById('detailPlaceCategory').textContent = categories[place.category_id] || 'Địa điểm';
        
        document.getElementById('detailPlaceDesc').textContent = place.description || "Chưa có thông tin mô tả chi tiết cho địa điểm này.";
        
        document.getElementById('detailStatRating').textContent = rating;
        document.getElementById('detailStatReviews').textContent = reviewCount;
        
        // Gắn ID hiện tại vào nút viết review ngay từ trong chi tiết
        const btnWriteReview = document.getElementById('btnWriteReviewFromDetail');
        if(btnWriteReview) {
            btnWriteReview.onclick = () => {
                closePlaceDetail.click();
                setTimeout(() => {
                    const openReview = document.getElementById('openAddReviewModal');
                    if(openReview) openReview.click();
                    
                    // Hacky cách select địa điểm
                    setTimeout(() => {
                        const select = document.getElementById('reviewPlaceId');
                        if (select) {
                            select.value = place.id;
                        }
                    }, 50);
                }, 300);
            }
        }
        
        // Hiện modal
        placeDetailModal.classList.remove('hidden');
        setTimeout(()=> placeDetailModal.classList.remove('translate-y-full'), 10);
    }
    
    if(closePlaceDetail) {
        closePlaceDetail.addEventListener('click', () => {
            placeDetailModal.classList.add('translate-y-full');
            setTimeout(()=> placeDetailModal.classList.add('hidden'), 300);
        });
    }

    // Init
    loadFeed();
});
