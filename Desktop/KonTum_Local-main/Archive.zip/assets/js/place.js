document.addEventListener('DOMContentLoaded', () => {
    const mainActionBtn = document.getElementById('mainActionBtn');
    const plusMenu = document.getElementById('plusMenu');
    const closePlusMenu = document.getElementById('closePlusMenu');
    const openAddPlaceModal = document.getElementById('openAddPlaceModal');
    const openAddReviewModal = document.getElementById('openAddReviewModal');

    const placeModal = document.getElementById('placeModal');
    const closePlaceModal = document.getElementById('closePlaceModal');
    const submitPlaceBtn = document.getElementById('submitPlaceBtn');

    const reviewModal = document.getElementById('reviewModal'); // Handled in review.js but we need to open it

    // --- 1. Plus Menu Toggle ---
    if (mainActionBtn) {
        mainActionBtn.addEventListener('click', () => {
            plusMenu.classList.remove('hidden');
        });
    }

    if (closePlusMenu) {
        closePlusMenu.addEventListener('click', () => {
            plusMenu.classList.add('hidden');
        });
    }

    // --- 2. Open Specific Modals ---
    if (openAddPlaceModal) {
        openAddPlaceModal.addEventListener('click', () => {
            if (!localStorage.getItem('user_vtkt')) {
                showToast("Vui lòng đăng nhập để đóng góp!", "error");
                plusMenu.classList.add('hidden');
                document.querySelector('.nav-btn[data-target="profile"]').click();
                return;
            }
            plusMenu.classList.add('hidden');
            placeModal.classList.remove('hidden');
            setTimeout(() => placeModal.classList.remove('translate-y-full'), 10);
        });
    }

    if (openAddReviewModal) {
        openAddReviewModal.addEventListener('click', () => {
            if (!localStorage.getItem('user_vtkt')) {
                showToast("Vui lòng đăng nhập để đánh giá!", "error");
                plusMenu.classList.add('hidden');
                document.querySelector('.nav-btn[data-target="profile"]').click();
                return;
            }
            plusMenu.classList.add('hidden');
            reviewModal.classList.remove('hidden');
            setTimeout(() => reviewModal.classList.remove('translate-y-full'), 10);
        });
    }

    // --- 3. Place Modal Close ---
    if (closePlaceModal) {
        closePlaceModal.addEventListener('click', () => {
            placeModal.classList.add('translate-y-full');
            setTimeout(() => placeModal.classList.add('hidden'), 300);
        });
    }

    // --- 4. Submit Place Logic ---
    if (submitPlaceBtn) {
        submitPlaceBtn.addEventListener('click', async () => {
            const name = document.getElementById('placeName').value.trim();
            const category_id = document.getElementById('placeCategory').value;
            const address = document.getElementById('placeAddress').value.trim();
            const description = document.getElementById('placeDesc').value.trim();
            const user = JSON.parse(localStorage.getItem('user_vtkt'));

            if (!name || !address) {
                showToast("Vui lòng nhập tên và địa chỉ!", "error");
                return;
            }

            submitPlaceBtn.disabled = true;
            submitPlaceBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';

            try {
                const res = await fetch('https://local.kontumplus.com/api/places.php?action=add_place', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'add_place',
                        name,
                        category_id,
                        address,
                        description,
                        user_id: user.id,
                        latitude: 14.35, // Mock coords
                        longitude: 108.0
                    })
                });
                const data = await res.json();

                if (data.status === 'success') {
                    showToast(data.message, "success");

                    // Update Points in local storage for instant feedback
                    user.points = (user.points || 0) + 15;
                    localStorage.setItem('user_vtkt', JSON.stringify(user));

                    // Sync Profile UI
                    if (document.getElementById('profilePoints')) {
                        document.getElementById('profilePoints').textContent = user.points;
                    }

                    // Reset & Close
                    document.getElementById('placeName').value = '';
                    document.getElementById('placeAddress').value = '';
                    document.getElementById('placeDesc').value = '';
                    closePlaceModal.click();
                } else {
                    showToast(data.message, "error");
                }
            } catch (err) {
                console.error(err);
                showToast("Lỗi kết nối máy chủ", "error");
            } finally {
                submitPlaceBtn.disabled = false;
                submitPlaceBtn.textContent = 'Gửi';
            }
        });
    }
});
