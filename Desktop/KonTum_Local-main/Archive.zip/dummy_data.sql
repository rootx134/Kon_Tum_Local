SET FOREIGN_KEY_CHECKS = 0;

-- Clear previous data to avoid duplicates if re-running
DELETE FROM `review_images`;
DELETE FROM `likes`;
DELETE FROM `reviews`;
DELETE FROM `place_images`;
DELETE FROM `places`;
DELETE FROM `users` WHERE `username` NOT IN ('admin');

-- 1. Users
INSERT INTO `users` (`username`, `password`, `fullname`, `avatar`, `points`) VALUES
('user1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Nguyễn Văn A', 'user1.png', 1250),
('user2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Trần Thị B', 'user2.png', 840),
('user3', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Lê Minh C', 'user3.png', 3200);

-- 2. Places
-- Category IDs: 1: Ăn uống, 2: Giải trí, 3: Khách sạn, 4: Du lịch
INSERT INTO `places` (`id`, `category_id`, `name`, `description`, `address`, `status`, `submitted_by`) VALUES
(1, 1, 'Quán Cơm Gà Bà Luận', 'Cơm gà Tam Kỳ chuẩn vị ngon nhất Kon Tum. Không gian rộng rãi thoáng mát.', '123 Phan Đình Phùng, TP Kon Tum', 'approved', 1),
(2, 4, 'Nhà Thờ Gỗ Kon Tum', 'Kiến trúc bằng gỗ độc đáo mang đậm phong cách Ba Na và Roman. Tuổi đời hơn 100 năm.', '13 Nguyễn Huệ, TP Kon Tum', 'approved', 1),
(3, 1, 'Gỏi Lá Kon Tum - Út Cưng', 'Đặc sản gỏi lá với hàng chục loại lá rừng tươi ngon, ăn kèm thịt ba chỉ và tôm.', '45 Trần Hưng Đạo, TP Kon Tum', 'approved', 2),
(4, 4, 'Cầu treo Kon Klor', 'Cầu treo công nghiệp lớn nhất Tây Nguyên, bắc qua dòng sông Đăk Bla huyền thoại.', 'Bắc Kạn, TP Kon Tum', 'approved', 2),
(5, 1, 'Café Indochine', 'Thiết kế tre độc đáo của KTS Võ Trọng Nghĩa, không gian mở view sông cực đẹp.', '30 Bạch Đằng, TP Kon Tum', 'approved', 3),
(6, 3, 'Khách sạn Indochine', 'Khách sạn sang trọng bậc nhất Kon Tum với đầy đủ tiện nghi và hồ bơi.', '30 Bạch Đằng, TP Kon Tum', 'approved', 3),
(7, 4, 'Khu du lịch Măng Đen', 'Đà Lạt thứ hai của Tây Nguyên với khí hậu ôn hòa và những cánh rừng thông bát ngát.', 'Huyện Kon Plông, Kon Tum', 'approved', 1),
(8, 2, 'Công viên 17/3', 'Nơi thư giãn và tập thể dục lý tưởng cho người dân địa phương vào mỗi buổi chiều.', 'Đường Lê Hồng Phong, TP Kon Tum', 'approved', 2);

-- 3. Place Images
INSERT INTO `place_images` (`place_id`, `image_url`) VALUES
(1, 'https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?auto=format&fit=crop&q=80&w=600'),
(2, 'https://vcdn1-dulich.vnecdn.net/2021/10/26/Nha-tho-go-Kon-Tum-1-1635235541.jpg?w=1200&h=0&q=100&dpr=1&fit=crop&s=x6_C9f9Y9z9X9z9X9z9X9w'),
(3, 'https://statics.vinpearl.com/goi-la-kon-tum-1_1669273767.jpg'),
(4, 'https://vcdn1-dulich.vnecdn.net/2021/10/26/Cau-treo-Kon-Klor-1635235541.jpg?w=1200&h=0&q=100&dpr=1&fit=crop&s=x6_C9f9Y9z9X9z9X9z9X9w'),
(5, 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&q=80&w=600'),
(7, 'https://vcdn1-dulich.vnecdn.net/2022/08/10/mang-den-1-1660124445.jpg?w=1200&h=0&q=100&dpr=1&fit=crop&s=x6_C9f9Y9z9X9z9X9z9X9w');

-- 4. Reviews
INSERT INTO `reviews` (`id`, `place_id`, `user_id`, `rating`, `content`) VALUES
(1, 1, 2, 5, 'Cơm gà siêu ngon, thịt luộc dai mềm vừa tới. Nước chấm gừng rất đặc biệt! Sẽ quay lại 100%.'),
(2, 2, 3, 5, 'Địa điểm du lịch tâm linh cổ kính tuyệt đẹp. Sáng thức dậy dạo quanh nhà thờ thật sự bình yên và thanh tịnh.'),
(3, 3, 1, 4, 'Trải nghiệm ẩm thực độc lạ. Gỏi lá có vị chát, ngọt, cay hòa quyện rất khó quên. Tuy nhiên quán hơi đông vào cuối tuần.'),
(4, 5, 2, 5, 'Thiết kế tre quá ấn tượng! Ngồi uống cafe đón gió sông Đăk Bla thư giãn vô cùng. Giá cả hợp lý.'),
(5, 4, 3, 4, 'Cầu treo rất dài và đẹp. Nên đến đây vào lúc hoàng hôn để chụp ảnh, bao lung linh luôn mọi người ơi!'),
(6, 7, 1, 5, 'Khí hậu tuyệt vời, mát mẻ quanh năm. Rất thích hợp cho những chuyến đi nghỉ dưỡng cùng gia đình.');

-- 5. Review Images
INSERT INTO `review_images` (`review_id`, `image_url`) VALUES
(1, 'https://images.unsplash.com/photo-1590487339174-8b6ee7b2605f?auto=format&fit=crop&q=80&w=400'),
(2, 'https://images.unsplash.com/photo-1533580554558-868ed448eff2?auto=format&fit=crop&q=80&w=400'),
(2, 'https://images.unsplash.com/photo-1519046904884-53103b34b206?auto=format&fit=crop&q=80&w=400'),
(3, 'https://img-global.cpcdn.com/recipes/53066377755a5330/680x482cq70/goi-la-kon-tum-recipe-main-photo.jpg'),
(4, 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&q=80&w=400'),
(6, 'https://statics.vinpearl.com/mang-den-kon-tum-01_1669273767.jpg'),
(6, 'https://vcdn1-dulich.vnecdn.net/2022/02/10/mang-den-1-1644482065.jpg?w=1200&h=0&q=100&dpr=1&fit=crop&s=x6_C9f9Y9z9X9z9X9z9X9w');

-- 6. Likes
INSERT INTO `likes` (`user_id`, `entity_type`, `entity_id`) VALUES
(2, 'review', 1), (3, 'review', 1), (1, 'review', 1),
(2, 'review', 2), (1, 'review', 2),
(3, 'review', 3), (2, 'review', 3),
(1, 'review', 4), (3, 'review', 4),
(2, 'review', 5),
(3, 'review', 6), (2, 'review', 6), (1, 'review', 6);
SET FOREIGN_KEY_CHECKS = 1;
